using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerState : MonoBehaviour
{
    [CreateAssetMenu(fileName = "PlayerData", menuName = "ScriptableObjects/PlayerDataSO")]
    public class SpawnManagerScriptableObject : ScriptableObject
    {
        public int wave;
        public int level;
        public int experience;
    }
}
