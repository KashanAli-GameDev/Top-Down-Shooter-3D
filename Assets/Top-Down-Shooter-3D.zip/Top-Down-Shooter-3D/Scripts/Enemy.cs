using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Enemy : MonoBehaviour
{
    [SerializeField] GameObject _gemsPrefab;

    [Header("UI Field")]
    [SerializeField] TextMeshProUGUI healthTmp;

    [Header("Enemy attributes.")]
    [SerializeField] int maxHealth = 2;
    [SerializeField] int speed = 2;
    [SerializeField] int damage = 1;
    [SerializeField] float followRange = 1.5f;

    [Header("Enemy Damage Attributes.")]
    [SerializeField] float damageRate = 1;


    [SerializeField] LayerMask playerLayer;

    int currentHealth;
    
    float targetDistance;
    Vector3 lookDirection;
    Quaternion lookRotation;

    GameObject player;
    Collider boxCollider;
    Rigidbody rb;


    float nextDamageTime = 0f;


    /// Start is called before the first frame update
    private void OnEnable()
    {
        player = GameObject.FindGameObjectWithTag("Player");

        currentHealth = maxHealth;

        boxCollider = GetComponent<BoxCollider>();

        rb = GetComponent<Rigidbody>();
    }

    /// Update is called once per frame
    private void Update()
    {
        healthTmp.text = $"{currentHealth}";

        LookTowardsTargat();
        MoveTowardsTargat();

        if (transform.position.y > 1.4f)
        {
            currentHealth = 0;
        }
    }
    private void LateUpdate()
    {
        ObjectDetector();
    }

    void LookTowardsTargat()
    {
        /// Calculate the direction to the target.
        lookDirection = player.transform.position - transform.position;
        lookDirection.y = 0; /// Set Y component to zero to avoid X-axis rotation.

        /// Rotate only around the Y-axis to face the target.
        lookRotation = Quaternion.LookRotation(lookDirection);
    }

    float gravityStrength = 30f;
    private void MoveTowardsTargat()
    {
        targetDistance = Vector3.Distance(transform.position, player.transform.position);

        if (targetDistance >= followRange)
        {
            /// Apply the rotation to the object.
            transform.rotation = lookRotation;
            /// Follow player.

            rb.velocity = transform.forward.normalized * speed;

            /// Apply a downward force along the Y-axis
            Vector3 downwardForce = Vector3.down * gravityStrength;
            rb.AddForce(downwardForce);
        }
    }

    public void TakeDamage(int damage)
    {
        if (currentHealth > 0)
        {
            currentHealth -= damage;
        }
        Death();
    }

    void Death()
    {
        if (currentHealth < 1)
        {
            currentHealth = 0;
            Instantiate(_gemsPrefab, transform.position, _gemsPrefab.transform.rotation);
            Destroy(gameObject);
        }
    }

    void ObjectDetector()
    {
        Collider[] colliders = Physics.OverlapBox(boxCollider.bounds.center, boxCollider.bounds.size / followRange, transform.rotation, playerLayer);

        foreach (Collider collider in colliders)
        {
            if (collider.gameObject.CompareTag("Player"))
            {
                DamagePlayer();
            }
        }
    }

    void DamagePlayer()
    {
        if (Time.time >= nextDamageTime)
        {
            player.GetComponent<Player>().TakeDamage(damage);
            
            nextDamageTime = Time.time + 1f / damageRate;
        }
    }
}
