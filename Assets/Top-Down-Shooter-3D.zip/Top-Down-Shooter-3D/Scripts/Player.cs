using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Player : MonoBehaviour
{
    [Header("UI Field")]
    public int xp;
    [SerializeField] TextMeshProUGUI xpTmp;
    [SerializeField] TextMeshProUGUI healthTmp;

    [Header("Joystick Fields.")]
    [SerializeField] VariableJoystick variableJoystick;

    [Header("Player Fields.")]
    public int damage = 1;
    [SerializeField] int speed = 5;
    [SerializeField] int maxHealth = 5;

    [Header("Enemy Dectector Fields.")]
    [SerializeField] float detectorRange = 5;
    [SerializeField] LayerMask enemyLayer;

    [Header("Shooting Fields.")]
    [SerializeField] GameObject bulletPrefabs;
    [SerializeField] Transform bulletSpawnPoint;
    [SerializeField] float fireRate = 1;

    /// Condition Inputs for gun firerate.
    float nextFireTime = 0f;
    [SerializeField] int currentHealth;

    bool targatDetected = false;
    float distanceDirection;
    Vector3 lookDirection;
    Quaternion lookRotation;
    
    [SerializeField] GameObject Targat;


    private void OnEnable()
    {
        currentHealth = maxHealth;
    }

    private void Update()
    {
        xpTmp.text = $"Xp: {xp}";
        healthTmp.text = $"Health: {currentHealth}";

        PlayerMovement();

        LookTowardsTargat();
    }

    private void LateUpdate()
    {
        EnemyTargatDetector();
    }

    void PlayerMovement()
    {
        float verticalInput;
        float horizontalInput;
#if UNITY_STANDALONE_WIN

        verticalInput = Input.GetAxis("Vertical");
        horizontalInput = Input.GetAxis("Horizontal");

#endif

#if UNITY_ANDROID

        verticalInput = variableJoystick.Vertical;
        horizontalInput = variableJoystick.Horizontal;

#endif

        Vector3 movment = new Vector3(horizontalInput, 0, verticalInput).normalized;

        transform.Translate(movment * speed * Time.deltaTime, Space.World);
    }


    void EnemyTargatDetector()
    {
        targatDetected = false;
        
        Collider[] enemies = Physics.OverlapSphere(transform.position, detectorRange, enemyLayer);

        foreach (var collider in enemies)
        {
            targatDetected = true;
            Targat = collider.gameObject;
        }

        if (!targatDetected)
        {
            Targat = null;
        }
    }

    void LookTowardsTargat()
    {
        if (Targat != null)
        {
            /// Calculate the direction to the target.
            lookDirection = Targat.transform.position - transform.position;
            lookDirection.y = 0; /// Set Y component to zero to avoid X-axis rotation.

            /// Rotate only around the Y-axis to face the target.
            lookRotation = Quaternion.LookRotation(lookDirection);

            /// Apply the rotation to the object.
            transform.rotation = lookRotation;

            Shooting();
        }
        else
        {
            transform.rotation = Quaternion.Euler(Vector3.zero);
            return;
        }

    }

    void Shooting()
    {
        if (Time.time >= nextFireTime)
        {
            Instantiate(bulletPrefabs.gameObject, bulletSpawnPoint.position, bulletPrefabs.transform.rotation);

            nextFireTime = Time.time + 1f / fireRate;
        }
    }


    /// Draw Gizmos on custom sphere collider.
    private void OnDrawGizmos()
    {
        ///  Show detector's gizmos.
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position, detectorRange);
    }

    public void TakeDamage(int damage)
    {
        if (currentHealth > 0)
        {
            currentHealth -= damage;
        }
        Death();
    }

    void Death()
    {
        if (currentHealth < 1)
        {
            currentHealth = 0;

            Destroy(gameObject);

            Time.timeScale = 0;
        }
    }

    private void OnDestroy()
    {
        xpTmp.text = $"Xp: {xp}";
        healthTmp.text = $"Health: {currentHealth}";
    }

    /// UI Button Method.
    public void IncreaseDamage()
    {
        if (xp >= 15)
        {
            xp -= 15;
            damage++;
        }
    }

    /// UI Button Method.
    public void IncreaseFireRate()
    {
        if (xp >= 15)
        {
            xp -= 15;
            fireRate++;
        }
    }
}
