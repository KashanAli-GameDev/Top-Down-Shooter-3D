using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCamera : MonoBehaviour
{
    public Transform player; // The target to follow
    Vector3 offset; // The target to follow
    public float smoothSpeed = 5f; // The smoothness factor

    private void OnEnable()
    {
        offset = transform.position;
    }

    void LateUpdate()
    {
        if (player != null)
        {
            // Calculate the desired position based on the target's position
            Vector3 desiredPosition = player.position + offset;

            // Use SmoothDamp to smoothly interpolate the current position to the desired position
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

            // Set the camera's position to the smoothed position
            transform.position = smoothedPosition;
        }

        ExitGame();
    }


    void ExitGame()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {

#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif

        }
    }
}
