using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Header("Bullet Fields.")]
    //  [SerializeField] int damage = 1;
    [SerializeField] float bulletSpeed = 30;
    [SerializeField] float bulletDestroyTime = 2;

    [Header("Enemy Dectector Fields.")]
    [SerializeField] float detectorRange = 1;
    [SerializeField] LayerMask enemyLayer;

    GameObject player;


    private void OnEnable()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    private void Update()
    {
        BulletFire();
    }

    private void LateUpdate()
    {
        EnemyDetector();
    }

    void BulletFire()
    {
        /// Get the player's rotation
        Quaternion playerRotation = player.transform.rotation;

        /// Calculate the bullet's forward direction based on the player's facing direction
        Vector3 bulletDirection = playerRotation * Vector3.forward;

        /// Move the bullet in the calculated direction
        transform.Translate(bulletDirection * bulletSpeed * Time.deltaTime, Space.World);

        Destroy(gameObject, bulletDestroyTime);

    }
    void EnemyDetector()
    {
        Collider[] enemies = Physics.OverlapSphere(transform.position, detectorRange, enemyLayer);

        foreach (var collider in enemies)
        {
            if (collider.CompareTag("Enemy"))
            {
                collider.gameObject.GetComponent<Enemy>().TakeDamage(player.GetComponent<Player>().damage);
                Destroy(gameObject);
            }
        }
    }

    private void OnDrawGizmos()
    {
        ///  Show detector's gizmos.
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position, detectorRange);
    }
}
