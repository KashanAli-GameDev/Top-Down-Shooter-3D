using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

[System.Serializable]
public class Wave
{
    public int lightEnemyCount;
    public int mediumEnemyCount;
    public int heavyEnemyCount;
}

public class EnemySpawner : MonoBehaviour
{
    [Header("UI Field")]
    [SerializeField] TextMeshProUGUI waveTmp;

    [Header("Enemy Prefab Type Field")]
    public GameObject _lightEnemyPrefab;
    public GameObject _mediumEnemyPrefab;
    public GameObject _heavyEnemyPrefab;

    [Header("Wave Field")]
    [SerializeField] List<Wave> waves;
    [SerializeField] int currentWave;
    [SerializeField] float waveInterval = 5f;

    [Header("Enemy Spawn Attributes")]
    [SerializeField] float enemyInterval = 2f;
    float nextEnemyTime;

    [Header("Player Fields")]
    [SerializeField] GameObject playerObj;


    private void Update()
    {
        EnemiesInWaves();
    }

    void EnemiesInWaves()
    {
        if (currentWave >= waves.Count)
            return;

        waveTmp.text = $"Wave: {currentWave + 1}";

        /// Current Wave Light enemies.
        for (int lightNum = 0; lightNum < waves[currentWave].lightEnemyCount; lightNum++)
        {
            SpawnEnemies(_lightEnemyPrefab);
        }

        /// Current Wave Medium enemies.
        for (int mediumNum = 0; mediumNum < waves[currentWave].mediumEnemyCount; mediumNum++)
        {
            SpawnEnemies(_mediumEnemyPrefab);
        }

        /// Wave Count Heavy enemies.
        for (int heavyNum = 0; heavyNum < waves[currentWave].heavyEnemyCount; heavyNum++)
        {
            SpawnEnemies(_heavyEnemyPrefab);
        }
    }

    private void SpawnEnemies(GameObject enemyType)
    {
        if (Time.time >= nextEnemyTime)
        {
            Instantiate(enemyType, RandomPosition(), Quaternion.identity);

            DecreaseEnemyCount();
            CheckEnemyCountInWave();

            nextEnemyTime = Time.time + 1f / enemyInterval;
        }
    }

    void CheckEnemyCountInWave()
    {
        if (waves[currentWave].lightEnemyCount <= 0 && waves[currentWave].mediumEnemyCount <= 0 && waves[currentWave].heavyEnemyCount <= 0)
        {
            StartCoroutine(WaveIncreamentDelay());
        }
    }

    IEnumerator WaveIncreamentDelay()
    {
        yield return new WaitForSeconds(waveInterval);
        currentWave++;
    }

    void DecreaseEnemyCount()
    {
        if (waves[currentWave].lightEnemyCount > 0)
        {
            waves[currentWave].lightEnemyCount--;
        }

        if (waves[currentWave].mediumEnemyCount > 0)
        {
            waves[currentWave].mediumEnemyCount--;
        }

        if (waves[currentWave].heavyEnemyCount > 0)
        {
            waves[currentWave].heavyEnemyCount--;
        }
    }
    Vector3 _spawnPos;
    private Vector3 RandomPosition()
    {
        float randomX;
        float randomZ;
        Vector3 randomXYZ;

        /// Keep generating new vectors until it's significantly different from the previous one
        do
        {
            randomX = Random.Range(-9f, 9f);
            randomZ = Random.Range(-9f, 9f);
            randomXYZ = new Vector3(randomX, 0.5f, randomZ);
        }
        while (Vector3.Distance(randomXYZ, _spawnPos) < 5.0f && Vector3.Distance(randomXYZ, playerObj.transform.position) < 10.0f);

        /// Set lastSpawnPosition to the newly generated position
        _spawnPos = new Vector3(randomX, 0.5f, randomZ);

        return _spawnPos;
    }
}
